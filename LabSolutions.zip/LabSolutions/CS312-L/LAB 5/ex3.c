#include <stdio.h>
#include <unistd.h>

int main()
{
	char *args[] = {"ls", "-a", "/bin", NULL};

	execv("/bin/ls", args);
	return 0;
}
