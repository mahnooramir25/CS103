#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define BUFFER_SIZE 256

int main() {
    char buffer[BUFFER_SIZE]; // Buffer to store input
    ssize_t bytes_read;

    // Reading data from the shell (file descriptor 0)
    while ((bytes_read = read(0, buffer, BUFFER_SIZE)) > 0) {
        // Echoing the input back to the shell (file descriptor 1)
        if (write(1, buffer, bytes_read) != bytes_read) {
            perror("write");
            exit(EXIT_FAILURE);
        }
    }

    if (bytes_read == -1) {
        perror("read");
        exit(EXIT_FAILURE);
    }

    printf("End of input reached. Program terminated.\n");

    return 0;
}

