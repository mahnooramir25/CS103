#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t child_pid = fork();

    if (child_pid == -1) {
        perror("Error forking");
        exit(EXIT_FAILURE);
    } else if (child_pid == 0) {
        // Child process
        printf("Child process executing...\n");
        execlp("date", "date", NULL); // Replace with the 'date' command
        perror("Error executing date");
        exit(EXIT_FAILURE);
    } else {
        // Parent process
        printf("Parent process waiting for the child...\n");
        wait(NULL); // Wait for the child process to finish
        printf("Parent process resumed after child execution.\n");
    }

    return 0;
}

