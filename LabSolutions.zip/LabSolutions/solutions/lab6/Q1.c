#include <stdio.h>
#include <unistd.h>

int main() {
    printf("Before exec(): This message is what Mahnoor wrote originally.\n");

    // Replace the current process with a new program (e.g., /bin/ls)
    execl("/bin/ls", "ls", "-l", NULL);

    // This line will never be reached because of the exec() call
    printf("After exec(): Sadly this message will never appear.\n");

    return 0;
}

