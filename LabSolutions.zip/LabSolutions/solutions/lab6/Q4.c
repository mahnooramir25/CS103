#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    // Set an environment variable
    char *env_vars[] = {"MY_VARIABLE=HelloFromEnvironment", NULL};

    // Arguments to pass
    char *args[] = {"./Q1", "arg1", "arg2", NULL};

    // Execute the new program
    execve("./Q1", args, env_vars);

    // If execve fails, print an error
    perror("execve");
    return 1;
}

