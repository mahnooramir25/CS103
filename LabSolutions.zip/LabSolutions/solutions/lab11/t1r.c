#include<stdio.h>            // Standard input-output library
#include<sys/ipc.h>          // Definitions for interprocess communication
#include<sys/shm.h>          // Shared memory operations
#include<sys/types.h>        // Definitions for system calls
#include<string.h>           // String handling functions
#include<errno.h>            // Error handling
#include<stdlib.h>           // Standard library functions
#include<unistd.h>

#define BUF_SIZE 1024        // Size of the buffer
#define SHM_KEY 0x1234       // Key for shared memory segment creation

struct shmseg {
   int cnt;                 // Count of bytes read from/written to buffer
   int complete;            // Flag indicating completion of data transfer
   char buf[BUF_SIZE];      // Buffer to store data
};

int main(int argc, char *argv[]) {
   int shmid;                // Shared memory ID
   struct shmseg *shmp;      // Pointer to shared memory segment

   // Create or get the ID of a shared memory segment
   shmid = shmget(SHM_KEY, sizeof(struct shmseg), 0644|IPC_CREAT);
   if (shmid == -1) {
      perror("Shared memory");
      return 1;
   }
   
   // Attach to the shared memory segment to obtain a pointer to it
   shmp = shmat(shmid, NULL, 0);
   if (shmp == (void *) -1) {
      perror("Shared memory attach");
      return 1;
   }
   
   /* Transfer blocks of data from shared memory to stdout */
   while (shmp->complete != 1) {
      // Print the contents of the shared memory segment
      printf("segment contains : \n\"%s\"\n", shmp->buf);
      if (shmp->cnt == -1) {
         perror("read");
         return 1;
      }
      printf("Reading Process: Shared Memory: Read %d bytes\n", shmp->cnt);
      sleep(3);   // Pause for a moment
   }
   printf("Reading Process: Reading Done, Detaching Shared Memory\n");
   
   // Detach from the shared memory segment
   if (shmdt(shmp) == -1) {
      perror("shmdt");
      return 1;
   }
   printf("Reading Process: Complete\n");
   return 0;
}

