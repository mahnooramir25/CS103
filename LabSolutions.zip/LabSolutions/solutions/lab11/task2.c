//Write two programs where the writer creates a message queue & then writes some text to it. 
//The reader then receives that message & ultimately deletes the message queue.
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define MAX 10

// Structure for the message queue
struct mesg_buffer {
    long mesg_type;
    char mesg_text[100];
} message;

int main() {
    key_t key;
    int msgid;

    // Generate a unique key for the message queue
    key = ftok("progfile", 65);

    // Create or open an existing message queue
    msgid = msgget(key, 0666 | IPC_CREAT);

    // Write data to the message queue
    message.mesg_type = 1;
    printf("Write Data: ");
    fgets(message.mesg_text, MAX, stdin);
    msgsnd(msgid, &message, sizeof(message), 0);
    printf("Data sent is: %s\n", message.mesg_text);

    // Read data from the message queue
    msgrcv(msgid, &message, sizeof(message), 1, 0);
    printf("Data received is: %s\n", message.mesg_text);

    // Remove the message queue
    msgctl(msgid, IPC_RMID, NULL);

    return 0;
}

