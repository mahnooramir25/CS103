#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <filename>\n", argv[0]);
        return 1;
    }

    char *filename = argv[1];
    int len = strlen(filename);
    if (len < 3 || strcmp(filename + len - 2, ".c") != 0) {
        printf("%s is not a C source file.\n", filename);
    } else {
        printf("%s is a C source file.\n", filename);
    }

    return 0;
}

