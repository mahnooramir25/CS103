#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 100

int stack[MAX_SIZE];
int top = -1;

void push(int data) {
    if (top == MAX_SIZE - 1) {
        fprintf(stderr, "Error: Stack overflow\n");
        exit(EXIT_FAILURE);
    } else {
        top++;
        stack[top] = data;
    }
}

int pop() {
    int data;
    if (top == -1) {
        fprintf(stderr, "Error: Stack underflow\n");
        exit(EXIT_FAILURE);
    } else {
        data = stack[top];
        top--;
        return data;
    }
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <element1> <element2> ... <elementN>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    for (int i = 1; i < argc; i++) {
        int data = atoi(argv[i]);
        push(data);
    }

    printf("Popped elements: ");
    int sum = 0;
    while (top != -1) {
        int num = pop();
        printf("%d ", num);
        sum += num;
    }

    printf("\nSum of popped elements: %d\n", sum);

    return 0;
}
