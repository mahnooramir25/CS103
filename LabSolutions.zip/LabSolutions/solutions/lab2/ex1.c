#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc != 4) {
        fprintf(stderr, "Usage: %s <operation: add, sub, mul, div> <num1> <num2>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    char *operation = argv[1];
    float num1 = atof(argv[2]);
    float num2 = atof(argv[3]);
    float result;

    if (strcmp(operation, "add") == 0) {
        result = num1 + num2;
    } else if (strcmp(operation, "sub") == 0) {
        result = num1 - num2;
    } else if (strcmp(operation, "mul") == 0) {
        result = num1 * num2;
    } else if (strcmp(operation, "div") == 0) {
        if (num2 == 0) {
            fprintf(stderr, "Error: Division by zero\n");
            exit(EXIT_FAILURE);
        }
        result = num1 / num2;
    } else if (strcmp(operation, "sqrt") == 0) {
        if (num1 < 0) {
            fprintf(stderr, "Error: Square root of negative number\n");
            exit(EXIT_FAILURE);
        }
        result = sqrt(num1);
    } else if (strcmp(operation, "pow") == 0) {
        result = pow(num1, num2);
    } else {
        fprintf(stderr, "Error: Invalid operation\n");
        exit(EXIT_FAILURE);
    }

    printf("Result: %.2f\n", result);

    return 0;
}
