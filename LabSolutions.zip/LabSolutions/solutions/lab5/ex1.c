#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

int main() {
    FILE *file = fopen("nonexistent_file.txt", "r");
    if (file == NULL) {
        perror("fopen");
        fprintf(stderr, "Error code: %d\n", errno);
        exit(EXIT_FAILURE);
    }

    // This part won't be reached if the file is not opened successfully
    printf("File opened successfully.\n");
    fclose(file);

    return 0;
}
